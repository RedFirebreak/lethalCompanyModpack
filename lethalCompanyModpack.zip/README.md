# Modpack LethalLikkertjes

GLHF, deze pack is omdat iedereen te lui was om 1 voor 1 alle mods te downloaden. Dan maar zo :)

## Installatie
1. Maak een nieuw profiel aan en activeer deze (Of delete al je mods)
2. Download de modpack "LethalLikkertjes"
3. Enjoy.

## Update
1. Zie installatie.